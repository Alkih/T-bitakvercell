
  # Türk Gelenekleri Uygulaması

  This is a code bundle for Türk Gelenekleri Uygulaması. The original project is available at https://www.figma.com/design/2QIrMmKg8uuA1KMfWDllt4/T%C3%BCrk-Gelenekleri-Uygulamas%C4%B1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  